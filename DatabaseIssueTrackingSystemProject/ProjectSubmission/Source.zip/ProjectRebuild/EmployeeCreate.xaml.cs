﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Data.SQLite;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ProjectRebuild
{
    /// <summary>
    /// Interaction logic for EmployeeCreate.xaml
    /// </summary>
    public partial class EmployeeCreate : Page
    {
        public class Ticket
        {
            public string TicketNum { get; set; }
            public string Created_For { get; set; }
            public string Assigned_To { get; set; }
            public string Contact_Type { get; set; }
            public string Category { get; set; }
            public string Is_Resolved { get; set; }
            public string Short_Desc { get; set; }
            public string Full_Desc { get; set; }
        }
        public class UserData
        {
            public string UserID { get; set; }
            public string First_Last { get; set; }
        }
        public string CreatedForStr = "None";
        public string AssignedToStr = "None";
        public string CreatedByStr = "None";
        public bool isCreatedForSet = false;
        public bool isAssignedToSet = false;
        public string is_checked = "0";
        public UserData userData;
        public Ticket ticketData;
        public EmployeeCreate(string UserID_str = "10000001")
        {
            InitializeComponent();
            CreatedByStr = UserID_str;
        }
        public class Model
        {
            static public List<string> GetData()
            {
                List<string> data = new List<string>();

                data.Add("Afzaal");
                data.Add("Ahmad");
                data.Add("Alonso");
                data.Add("Allison");
                data.Add("Alex");
                data.Add("Andrew");
                data.Add("Austin");
                data.Add("Albert");
                data.Add("Anderson");
                data.Add("Angelo");
                data.Add("Angel");
                data.Add("Zeeshan");
                data.Add("Daniyal");
                data.Add("Rizwan");
                data.Add("John");
                data.Add("Doe");
                data.Add("Johanna Doe");
                data.Add("Pakistan");
                data.Add("Microsoft");
                data.Add("Programming");
                data.Add("Visual Studio");
                data.Add("Sofiya");
                data.Add("Rihanna");
                data.Add("Eminem");

                return data;
            }
        }

        public class TableData
        {
            static public List<UserData> GetUsers(string query)
            {
                SQLiteConnection sqlite_conn;
                // Create a new database connection:
                sqlite_conn = new SQLiteConnection("Data Source=MyDatabase.db; " +
                    "Version= 3; New= True; Compress= True; Read Only= True;" +
                    "FailIfMissing=True;");
                // Open the connection:
                sqlite_conn.Open();
                SQLiteDataReader sqlite_datareader;
                SQLiteCommand sqlite_cmd;
                sqlite_cmd = sqlite_conn.CreateCommand();
                sqlite_cmd.CommandText =
                "SELECT U_ID as userid, U_FNAME||' '||U_LNAME AS firstlast " +
                "FROM USER WHERE firstlast LIKE '" + query + "%'";
                List<UserData> data = new List<UserData>();
                sqlite_datareader = sqlite_cmd.ExecuteReader();
                while (sqlite_datareader.Read())
                {
                    data.Add(new UserData()
                    {
                        UserID = Convert.ToString(sqlite_datareader.GetValue(0)),
                        First_Last = Convert.ToString(sqlite_datareader.GetValue(1))
                    });
                }
                sqlite_conn.Close();

                return data;
            }
            static public List<UserData> GetEmployees(string query)
            {
                SQLiteConnection sqlite_conn;
                // Create a new database connection:
                sqlite_conn = new SQLiteConnection("Data Source=MyDatabase.db; " +
                    "Version= 3; New= True; Compress= True; Read Only= True;" +
                    "FailIfMissing=True;");
                // Open the connection:
                sqlite_conn.Open();
                SQLiteDataReader sqlite_datareader;
                SQLiteCommand sqlite_cmd;
                sqlite_cmd = sqlite_conn.CreateCommand();
                sqlite_cmd.CommandText =
                "SELECT U_ID as userid, U_FNAME||' '||U_LNAME AS firstlast " +
                "FROM USER WHERE firstlast LIKE '" + query + "%' " +
                "AND U_TYPE='employee'";
                List<UserData> data = new List<UserData>();
                sqlite_datareader = sqlite_cmd.ExecuteReader();
                while (sqlite_datareader.Read())
                {
                    data.Add(new UserData()
                    {
                        UserID = Convert.ToString(sqlite_datareader.GetValue(0)),
                        First_Last = Convert.ToString(sqlite_datareader.GetValue(1))
                    });
                }
                sqlite_conn.Close();

                return data;
            }
            static public List<UserData> GetCustomers(string query)
            {
                SQLiteConnection sqlite_conn;
                // Create a new database connection:
                sqlite_conn = new SQLiteConnection("Data Source=MyDatabase.db; " +
                    "Version= 3; New= True; Compress= True; Read Only= True;" +
                    "FailIfMissing=True;");
                // Open the connection:
                sqlite_conn.Open();
                SQLiteDataReader sqlite_datareader;
                SQLiteCommand sqlite_cmd;
                sqlite_cmd = sqlite_conn.CreateCommand();
                sqlite_cmd.CommandText =
                "SELECT U_ID as userid, U_FNAME||' '||U_LNAME AS firstlast " +
                "FROM USER WHERE firstlast LIKE '" + query + "%' " +
                "AND U_TYPE='customer'";
                List<UserData> data = new List<UserData>();
                sqlite_datareader = sqlite_cmd.ExecuteReader();
                while (sqlite_datareader.Read())
                {
                    data.Add(new UserData()
                    {
                        UserID = Convert.ToString(sqlite_datareader.GetValue(0)),
                        First_Last = Convert.ToString(sqlite_datareader.GetValue(1))
                    });
                }
                sqlite_conn.Close();

                return data;
            }
        }
        private void CreateForLostKeyboardFocus(object sender, KeyboardFocusChangedEventArgs e)
        {
            if (isCreatedForSet == false && CreatedForTextBox.Text != "") //If we have not yet set CreatedForStr but the createdForTextbox has something in it
            {
                isCreatedForSet = true; //set to true as the caret is no longer inside the CreatedForTextBox (user clicked out of it) and user is not entering values
                SQLiteConnection sqlite_conn;
                // Create a new database connection:
                sqlite_conn = new SQLiteConnection("Data Source=MyDatabase.db; " +
                    "Version= 3; New= True; Compress= True; Read Only= True;" +
                    "FailIfMissing=True;");
                sqlite_conn.Open(); // Open the connection
                SQLiteDataReader sqlite_datareader;
                SQLiteCommand sqlite_cmd;
                sqlite_cmd = sqlite_conn.CreateCommand();
                sqlite_cmd.CommandText =
                "SELECT U_ID as userid, U_FNAME||' '||U_LNAME AS firstlast " +
                "FROM USER WHERE firstlast LIKE '" + CreatedForTextBox.Text.ToString() + "%'"; //query using what was in the textbox
                sqlite_datareader = sqlite_cmd.ExecuteReader(); //We will get only the first row as it should be the closest to the content inside the textbox
                sqlite_datareader.Read(); //Gets only the first row, which contains the primary suggestion for autocompletion
                CreatedForStr = Convert.ToString(sqlite_datareader.GetValue(0)); //get column 1 value
                CreatedForTextBox.Text = Convert.ToString(sqlite_datareader.GetValue(1)); // get column 2 value
                sqlite_conn.Close(); //close the connection
                MessageBox.Show("Success!");
            }
        }
        private void AssignedToLostKeyboardFocus(object sender, KeyboardFocusChangedEventArgs e)
        {
            if (isAssignedToSet == false && AssignedToTextBox.Text != "") //If we have not yet set AssignedToStr but the AssignedToTextbox has something in it
            {
                isAssignedToSet = true; //set to true as the caret is no longer inside the AssignedToTextBox (user clicked out of it) and user is not entering values
                SQLiteConnection sqlite_conn;
                // Create a new database connection:
                sqlite_conn = new SQLiteConnection("Data Source=MyDatabase.db; " +
                    "Version= 3; New= True; Compress= True; Read Only= True;" +
                    "FailIfMissing=True;");
                sqlite_conn.Open(); // Open the connection
                SQLiteDataReader sqlite_datareader;
                SQLiteCommand sqlite_cmd;
                sqlite_cmd = sqlite_conn.CreateCommand();
                sqlite_cmd.CommandText =
                "SELECT U_ID as userid, U_FNAME||' '||U_LNAME AS firstlast " +
                "FROM USER WHERE firstlast LIKE '" + AssignedToTextBox.Text.ToString() + "%'"; //query using what was in the textbox
                sqlite_datareader = sqlite_cmd.ExecuteReader(); //We will get only the first row as it should be the closest to the content inside the textbox
                sqlite_datareader.Read(); //Gets only the first row, which contains the primary suggestion for autocompletion
                AssignedToStr = Convert.ToString(sqlite_datareader.GetValue(0)); //get column 1 value
                AssignedToTextBox.Text = Convert.ToString(sqlite_datareader.GetValue(1)); // get column 2 value
                sqlite_conn.Close(); //close the connection
                MessageBox.Show("Success!");
            }
        }
        private void CreateForGotKeyboardFocus(object sender, KeyboardFocusChangedEventArgs e) //When user clicks inside the CreateForTextBox
        {
            isCreatedForSet = false; //Set to false as carat is now visible in CreateForTextBox and user is entering values
        }
        private void AssignedToGotKeyboardFocus(object sender, KeyboardFocusChangedEventArgs e) //When user clicks inside the AssignedToTextBox
        {
            isAssignedToSet = false; //Set to false as carat is now visible in AssignedToTextBox and user is entering values
        }
        private void CreatedForBox_KeyUp(object sender, KeyEventArgs e)
        {

            bool found = false;
            var border = (CreatedForStackPanel.Parent as ScrollViewer).Parent as Border;
            string query = (sender as TextBox).Text;
            var data = TableData.GetUsers(query);

            if (query.Length == 0)
            {
                // Clear
                CreatedForStackPanel.Children.Clear();
                border.Visibility = System.Windows.Visibility.Collapsed;
            }
            else
            {
                border.Visibility = System.Windows.Visibility.Visible;
            }

            // Clear the list
            CreatedForStackPanel.Children.Clear();

            // Add the result
            foreach (UserData obj in data)
                //{
                if (obj.First_Last.ToLower().StartsWith(query.ToLower()))
                {
                    // The word starts with this... Autocomplete must work
                    addItemTest(CreatedForStackPanel, CreatedForTextBox, obj);
                    found = true;
                }
            //}

            if (!found)
            {
                CreatedForStackPanel.Children.Add(new TextBlock() { Text = "No results found." });
            }
        }
        private void AssignedToBox_KeyUp(object sender, KeyEventArgs e)
        {
            bool found = false;
            var border = (AssignedToStackPanel.Parent as ScrollViewer).Parent as Border;
            string query = (sender as TextBox).Text;
            var data = TableData.GetEmployees(query);

            if (query.Length == 0)
            {
                // Clear
                AssignedToStackPanel.Children.Clear();
                border.Visibility = System.Windows.Visibility.Collapsed;
            }
            else
            {
                border.Visibility = System.Windows.Visibility.Visible;
            }

            // Clear the list
            AssignedToStackPanel.Children.Clear();

            // Add the result
            foreach (UserData obj in data)
            {
                if (obj.First_Last.ToLower().StartsWith(query.ToLower()))
                {
                    // The word starts with this... Autocomplete must work
                    addItemTest(AssignedToStackPanel, AssignedToTextBox, obj);
                    found = true;
                }
            }

            if (!found)
            {
                AssignedToStackPanel.Children.Add(new TextBlock() { Text = "No results found." });
            }
        }
        private void addItemTest(StackPanel stackPanel, TextBox textBox, UserData obj)
        {
            TextBlock block = new TextBlock();
            // Add the text
            block.Text = obj.First_Last;

            // A little style...
            block.Margin = new Thickness(2, 3, 2, 3);
            block.Cursor = Cursors.Hand;

            // Mouse events
            block.MouseLeftButtonUp += (sender, e) =>
            {
                textBox.Text = (sender as TextBlock).Text;
            };

            block.MouseEnter += (sender, e) =>
            {
                TextBlock b = sender as TextBlock;
                b.Background = Brushes.PeachPuff;
            };

            block.MouseLeave += (sender, e) =>
            {
                TextBlock b = sender as TextBlock;
                b.Background = Brushes.Transparent;
            };

            // Add to the panel
            stackPanel.Children.Add(block);
        }
        private void addItem(StackPanel stackPanel, TextBox textBox, string text)
        {
            TextBlock block = new TextBlock();

            // Add the text
            block.Text = text;

            // A little style...
            block.Margin = new Thickness(2, 3, 2, 3);
            block.Cursor = Cursors.Hand;

            // Mouse events
            block.MouseLeftButtonUp += (sender, e) =>
            {
                textBox.Text = (sender as TextBlock).Text;
            };

            block.MouseEnter += (sender, e) =>
            {
                TextBlock b = sender as TextBlock;
                b.Background = Brushes.PeachPuff;
            };

            block.MouseLeave += (sender, e) =>
            {
                TextBlock b = sender as TextBlock;
                b.Background = Brushes.Transparent;
            };

            // Add to the panel
            stackPanel.Children.Add(block);
        }

        private void CreateTicketButton_Click(object sender, RoutedEventArgs e)
        {
            SQLiteConnection sqlite_conn;
            // Create a new database connection:
            sqlite_conn = new SQLiteConnection("Data Source=MyDatabase.db; " +
                "Version= 3; New= True; Compress= True; " +
                "FailIfMissing=True;");
            // Open the connection:
            sqlite_conn.Open();
            SQLiteCommand sqlite_cmd;
            SQLiteDataReader sqlite_datareader;
            sqlite_cmd = sqlite_conn.CreateCommand();

            if (IsResolvedCheckBox.IsChecked == true)
            {
                is_checked = "1";
            }
            else if (IsResolvedCheckBox.IsChecked == false)
            {
                is_checked = "0";
            }
            string insertTicket = "INSERT INTO TICKET (CREATED_FOR, CREATED_BY, ASSIGNED_TO, CONTACT_TYPE, CATEGORY, IS_RESOLVED, SHORT_DESC, FULL_DESC) " +
            "VALUES('" + CreatedForStr + "', '" + CreatedByStr + "'," + AssignedToStr + ",'" + ContactTypeComboBox.Text + "', '" +
            CategoryComboBox.Text + "', " + is_checked + ",'" + ShortDescBox.Text + "', '" + FullDescBox.Text + "')";
            MessageBox.Show(insertTicket);
            sqlite_cmd.CommandText = insertTicket;
            sqlite_cmd.ExecuteNonQuery();
            sqlite_cmd = sqlite_conn.CreateCommand();
            sqlite_cmd.CommandText = "SELECT max(TICKET_NUM) FROM TICKET";
            sqlite_datareader = sqlite_cmd.ExecuteReader();
            sqlite_datareader.Read();
            string temp = "Your Ticket Number is: " + Convert.ToString(sqlite_datareader.GetValue(0));
            sqlite_conn.Close();
            MessageBox.Show(temp);
            CreateOrSearch createOrSearch = new CreateOrSearch();
            this.NavigationService.Navigate(createOrSearch);
        }

        private void ReturnButton_Click(object sender, RoutedEventArgs e)
        {
            CreateOrSearch createOrSearch = new CreateOrSearch();
            this.NavigationService.Navigate(createOrSearch);
        }
    }
}
