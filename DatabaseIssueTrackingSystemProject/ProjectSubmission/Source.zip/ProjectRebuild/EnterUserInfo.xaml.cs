﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Data.SQLite;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ProjectRebuild
{
    /// <summary>
    /// Interaction logic for EnterUserInfo.xaml
    /// </summary>
    public partial class EnterUserInfo : Page
    {
        public class UserData
        {
            public string UserID { get; set; }
            public string First_Last { get; set; }
            public string UserType { get; set; }
        }
        public class TableData
        {
            static public List<UserData> GetUsers(string query)
            {
                SQLiteConnection sqlite_conn;
                // Create a new database connection:
                sqlite_conn = new SQLiteConnection("Data Source=MyDatabase.db; " +
                    "Version= 3; New= True; Compress= True; Read Only= True;" +
                    "FailIfMissing=True;");
                // Open the connection:
                sqlite_conn.Open();
                SQLiteDataReader sqlite_datareader;
                SQLiteCommand sqlite_cmd;
                sqlite_cmd = sqlite_conn.CreateCommand();
                sqlite_cmd.CommandText =
                "SELECT U_ID as userid, U_FNAME||' '||U_LNAME AS firstlast, U_TYPE as usertype " +
                "FROM USER WHERE firstlast LIKE '" + query + "%'";
                List<UserData> data = new List<UserData>();
                sqlite_datareader = sqlite_cmd.ExecuteReader();
                while (sqlite_datareader.Read())
                {
                    data.Add(new UserData()
                    {
                        UserID = Convert.ToString(sqlite_datareader.GetValue(0)),
                        First_Last = Convert.ToString(sqlite_datareader.GetValue(1)),
                        UserType = Convert.ToString(sqlite_datareader.GetValue(2))
                    });
                }
                sqlite_conn.Close();

                return data;
            }
        }
        public string CreatedByStr = "None";
        public string UserTypeStr = "None";
        public string ConcatString = ""; //string used to store concatenation of column values obtained from SQL query
        public bool isCreatedBySet = false;
        public string decision_made = "";
        public EnterUserInfo(string create_or_search)
        {
            InitializeComponent();
            decision_made = create_or_search; //with this we know the user's decision up-front
        }
        private void CreatedByLostKeyboardFocus(object sender, KeyboardFocusChangedEventArgs e)
        {
            if (isCreatedBySet == false && CreatedByTextBox.Text != "") //If we have not yet set CreatedByStr but the createdByTextbox has something in it
            {
                isCreatedBySet = true; //set to true as the caret is no longer inside the CreatedByTextBox (user clicked out of it) and user is not entering values
                SQLiteConnection sqlite_conn;
                // Create a new database connection:
                sqlite_conn = new SQLiteConnection("Data Source=MyDatabase.db; " +
                    "Version= 3; New= True; Compress= True; Read Only= True;" +
                    "FailIfMissing=True;");
                sqlite_conn.Open(); // Open the connection
                SQLiteDataReader sqlite_datareader;
                SQLiteCommand sqlite_cmd;
                sqlite_cmd = sqlite_conn.CreateCommand();
                sqlite_cmd.CommandText =
                "SELECT U_ID as userid, U_FNAME||' '||U_LNAME AS firstlast, U_TYPE as usertype " +
                "FROM USER WHERE firstlast LIKE '" + CreatedByTextBox.Text.ToString() + "%'"; //query using what was in the textbox
                sqlite_datareader = sqlite_cmd.ExecuteReader(); //We will get only the first row as it should be the closest to the content inside the textbox
                sqlite_datareader.Read(); //Gets only the first row, which contains the primary suggestion for autocompletion
                CreatedByStr = Convert.ToString(sqlite_datareader.GetValue(0)); //get column 1 value
                UserTypeStr = Convert.ToString(sqlite_datareader.GetValue(2));
                ConcatString = Convert.ToString(sqlite_datareader.GetValue(1)) + " - " + UserTypeStr;
                CreatedByTextBox.Text = ConcatString;
                sqlite_conn.Close(); //close the connection
                MessageBox.Show("Success!");
            }
        }
        private void CreatedByGotKeyboardFocus(object sender, KeyboardFocusChangedEventArgs e) //When user clicks inside the CreatedByTextBox
        {
            isCreatedBySet = false; //Set to false as carat is now visible in CreatedByTextBox and user is entering values
        }
        private void addItemTest(StackPanel stackPanel, TextBox textBox, UserData obj)
        {
            TextBlock block = new TextBlock();
            // Add the text
            block.Text = obj.First_Last;

            // A little style...
            block.Margin = new Thickness(2, 3, 2, 3);
            block.Cursor = Cursors.Hand;

            // Mouse events
            block.MouseLeftButtonUp += (sender, e) =>
            {
                textBox.Text = (sender as TextBlock).Text;
            };

            block.MouseEnter += (sender, e) =>
            {
                TextBlock b = sender as TextBlock;
                b.Background = Brushes.PeachPuff;
            };

            block.MouseLeave += (sender, e) =>
            {
                TextBlock b = sender as TextBlock;
                b.Background = Brushes.Transparent;
            };

            // Add to the panel
            stackPanel.Children.Add(block);
        }
        private void CreatedByBox_KeyUp(object sender, KeyEventArgs e)
        {

            bool found = false;
            var border = (CreatedByStackPanel.Parent as ScrollViewer).Parent as Border;
            string query = (sender as TextBox).Text;
            var data = TableData.GetUsers(query);

            if (query.Length == 0)
            {
                // Clear
                CreatedByStackPanel.Children.Clear();
                border.Visibility = System.Windows.Visibility.Collapsed;
            }
            else
            {
                border.Visibility = System.Windows.Visibility.Visible;
            }

            // Clear the list
            CreatedByStackPanel.Children.Clear();

            // Add the result
            foreach (UserData obj in data)
                //{
                if (obj.First_Last.ToLower().StartsWith(query.ToLower()))
                {
                    // The word starts with this... Autocomplete must work
                    addItemTest(CreatedByStackPanel, CreatedByTextBox, obj);
                    found = true;
                }
            //}

            if (!found)
            {
                CreatedByStackPanel.Children.Add(new TextBlock() { Text = "No results found." });
            }
        }
        private void ContinueButton_Click(object sender, RoutedEventArgs e)
        {
            if (UserTypeStr == "customer")
            {
                if (decision_made == "create")
                {
                    CustomerCreate customerCreate = new CustomerCreate(CreatedByStr);
                    this.NavigationService.Navigate(customerCreate);
                }
                else if (decision_made == "search")
                {
                    CustomerSearch customerSearch = new CustomerSearch(CreatedByStr);
                    this.NavigationService.Navigate(customerSearch);
                }
            }

            if (UserTypeStr == "employee")
            {
                if (decision_made == "create")
                {
                    EmployeeCreate employeeCreate = new EmployeeCreate(CreatedByStr);
                    this.NavigationService.Navigate(employeeCreate);
                }
                else if (decision_made == "search")
                {
                    EmployeeSearch employeeSearch = new EmployeeSearch(CreatedByStr);
                    this.NavigationService.Navigate(employeeSearch);
                }
            }
        }
    }
}
