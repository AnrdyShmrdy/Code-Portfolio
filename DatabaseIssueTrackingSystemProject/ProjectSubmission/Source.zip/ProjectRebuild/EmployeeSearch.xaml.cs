﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Data.SQLite;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ProjectRebuild
{
    /// <summary>
    /// Interaction logic for EmployeeSearch.xaml
    /// </summary>
    public partial class EmployeeSearch : Page
    {
        public string CreatedByUID = "";
        public EmployeeSearch(string created_by)
        {
            InitializeComponent();
            CreatedByUID = created_by; //Makes it so that we know from previous page what the user ID was
        }
        private void SearchButton_Click(object sender, RoutedEventArgs e)
        {
            string input = TicketNumBox.Text;
            int ticket_num;
            try
            {
                ticket_num = Int32.Parse(input);
                Console.WriteLine(ticket_num);
            }
            catch (FormatException)
            {

                Console.WriteLine($"Invalid Ticket Number Input: '{input}'");
                MessageBox.Show($"Invalid Ticket Number Input: '{input}'");
                return;
            }
            EmployeeTicketDisplay TicketDisplay = new EmployeeTicketDisplay(ticket_num, input);
            this.NavigationService.Navigate(TicketDisplay);
        }
    }
}
