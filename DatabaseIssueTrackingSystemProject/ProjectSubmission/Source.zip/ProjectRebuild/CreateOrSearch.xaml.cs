﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Data.SQLite;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ProjectRebuild
{
    /// <summary>
    /// Interaction logic for CreateOrSearch.xaml
    /// </summary>
    public partial class CreateOrSearch : Page
    {
        public CreateOrSearch()
        {
            InitializeComponent();
        }
        private void createEnterUserInfo(object sender, RoutedEventArgs e)
        {
            EnterUserInfo enterUserInfo = new EnterUserInfo("create");
            this.NavigationService.Navigate(enterUserInfo);
        }

        private void searchEnterUserInfo(object sender, RoutedEventArgs e)
        {
            EnterUserInfo enterUserInfo = new EnterUserInfo("search");
            this.NavigationService.Navigate(enterUserInfo);
        }
    }
}
