﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Data.SQLite;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ProjectRebuild
{
    /// <summary>
    /// Interaction logic for EmployeeTicketDisplay.xaml
    /// </summary>
    public partial class EmployeeTicketDisplay : Page
    {
        public class Ticket
        {
            public string TicketNum { get; set; }
            public string Created_For { get; set; }
            public string Assigned_To { get; set; }
            public string Contact_Type { get; set; }
            public string Category { get; set; }
            public string Is_Resolved { get; set; }
            public string Short_Desc { get; set; }
            public string Full_Desc { get; set; }
        }
        public class UserData
        {
            public string UserID { get; set; }
            public string First_Last { get; set; }
        }
        public string CreatedForStr = "None";
        public string AssignedToStr = "None";
        public string CreatedByStr = "None";
        public string TicketNumStr = "";
        public bool isCreatedForSet = false;
        public bool isAssignedToSet = false;
        public string is_checked = "0";
        public UserData userData;
        public Ticket ticketData;
        public class TableData
        {
            static public List<UserData> GetUsers(string query)
            {
                SQLiteConnection sqlite_conn;
                // Create a new database connection:
                sqlite_conn = new SQLiteConnection("Data Source=MyDatabase.db; " +
                    "Version= 3; New= True; Compress= True; Read Only= True;" +
                    "FailIfMissing=True;");
                // Open the connection:
                sqlite_conn.Open();
                SQLiteDataReader sqlite_datareader;
                SQLiteCommand sqlite_cmd;
                sqlite_cmd = sqlite_conn.CreateCommand();
                sqlite_cmd.CommandText =
                "SELECT U_ID as userid, U_FNAME||' '||U_LNAME AS firstlast " +
                "FROM USER WHERE firstlast LIKE '" + query + "%'";
                List<UserData> data = new List<UserData>();
                sqlite_datareader = sqlite_cmd.ExecuteReader();
                while (sqlite_datareader.Read())
                {
                    data.Add(new UserData()
                    {
                        UserID = Convert.ToString(sqlite_datareader.GetValue(0)),
                        First_Last = Convert.ToString(sqlite_datareader.GetValue(1))
                    });
                }
                sqlite_conn.Close();

                return data;
            }
            static public List<UserData> GetEmployees(string query)
            {
                SQLiteConnection sqlite_conn;
                // Create a new database connection:
                sqlite_conn = new SQLiteConnection("Data Source=MyDatabase.db; " +
                    "Version= 3; New= True; Compress= True; Read Only= True;" +
                    "FailIfMissing=True;");
                // Open the connection:
                sqlite_conn.Open();
                SQLiteDataReader sqlite_datareader;
                SQLiteCommand sqlite_cmd;
                sqlite_cmd = sqlite_conn.CreateCommand();
                sqlite_cmd.CommandText =
                "SELECT U_ID as userid, U_FNAME||' '||U_LNAME AS firstlast " +
                "FROM USER WHERE firstlast LIKE '" + query + "%' " +
                "AND U_TYPE='employee'";
                List<UserData> data = new List<UserData>();
                sqlite_datareader = sqlite_cmd.ExecuteReader();
                while (sqlite_datareader.Read())
                {
                    data.Add(new UserData()
                    {
                        UserID = Convert.ToString(sqlite_datareader.GetValue(0)),
                        First_Last = Convert.ToString(sqlite_datareader.GetValue(1))
                    });
                }
                sqlite_conn.Close();

                return data;
            }
            static public List<UserData> GetCustomers(string query)
            {
                SQLiteConnection sqlite_conn;
                // Create a new database connection:
                sqlite_conn = new SQLiteConnection("Data Source=MyDatabase.db; " +
                    "Version= 3; New= True; Compress= True; Read Only= True;" +
                    "FailIfMissing=True;");
                // Open the connection:
                sqlite_conn.Open();
                SQLiteDataReader sqlite_datareader;
                SQLiteCommand sqlite_cmd;
                sqlite_cmd = sqlite_conn.CreateCommand();
                sqlite_cmd.CommandText =
                "SELECT U_ID as userid, U_FNAME||' '||U_LNAME AS firstlast " +
                "FROM USER WHERE firstlast LIKE '" + query + "%' " +
                "AND U_TYPE='customer'";
                List<UserData> data = new List<UserData>();
                sqlite_datareader = sqlite_cmd.ExecuteReader();
                while (sqlite_datareader.Read())
                {
                    data.Add(new UserData()
                    {
                        UserID = Convert.ToString(sqlite_datareader.GetValue(0)),
                        First_Last = Convert.ToString(sqlite_datareader.GetValue(1))
                    });
                }
                sqlite_conn.Close();

                return data;
            }
        }
        public void setContactTypeComboItem(string input)
        {
            if (chat.Content.ToString() == input)
            {
                ContactTypeComboBox.SelectedItem = chat;
            }
            else if (phone.Content.ToString() == input)
            {
                ContactTypeComboBox.SelectedItem = phone;
            }
            else if (email.Content.ToString() == input)
            {
                ContactTypeComboBox.SelectedItem = email;
            }
        }
        public void setCategoryComboItem(string input)
        {
            if (software.Content.ToString() == input)
            {
                CategoryComboBox.SelectedItem = software;
            }
            else if (hardware.Content.ToString() == input)
            {
                CategoryComboBox.SelectedItem = hardware;
            }
            else if (inquiryhelp.Content.ToString() == input)
            {
                CategoryComboBox.SelectedItem = inquiryhelp;
            }
        }
        public void setCheckBoxValue(string input)
        {
            if (input == "0")
                IsResolvedCheckBox.IsChecked = false;
            else if (input == "1")
                IsResolvedCheckBox.IsChecked = true;
        }
        public void getTicket(string ticket_str)
        {
            SQLiteConnection sqlite_conn;
            // Create a new database connection:
            sqlite_conn = new SQLiteConnection("Data Source=MyDatabase.db; " +
                "Version= 3; New= True; Compress= True; Read Only= True;" +
                "FailIfMissing=True;");
            // Open the connection:
            sqlite_conn.Open();
            SQLiteDataReader sqlite_datareader;
            SQLiteCommand sqlite_cmd;
            sqlite_cmd = sqlite_conn.CreateCommand();
            sqlite_cmd.CommandText = "SELECT * FROM TICKET WHERE TICKET_NUM = " + ticket_str;
            sqlite_datareader = sqlite_cmd.ExecuteReader();
            if (sqlite_datareader.Read())
            {
                TicketNumBlock.Text = Convert.ToString(sqlite_datareader.GetValue(0));
                CreatedForBlock.Text = Convert.ToString(sqlite_datareader.GetValue(1));
                CreatedByBlock.Text = Convert.ToString(sqlite_datareader.GetValue(2));
                AssignedToTextBox.Text = Convert.ToString(sqlite_datareader.GetValue(3));
                setContactTypeComboItem(Convert.ToString(sqlite_datareader.GetValue(4)));
                setCategoryComboItem(Convert.ToString(sqlite_datareader.GetValue(5)));
                setCheckBoxValue(Convert.ToString(sqlite_datareader.GetValue(6)));
                ShortDescBox.Text = Convert.ToString(sqlite_datareader.GetValue(7));
                FullDescBox.Text = Convert.ToString(sqlite_datareader.GetValue(8));
            }
            sqlite_conn.Close();
        }
        public EmployeeTicketDisplay(int ticket_num, string ticket_str)
        {
            InitializeComponent();
            getTicket(ticket_str);
            TicketNumStr = ticket_str;
        }

        private void ReturnButton_Click(object sender, RoutedEventArgs e)
        {
            CreateOrSearch createOrSearch = new CreateOrSearch();
            this.NavigationService.Navigate(createOrSearch);
        }

        private void UpdateTicketButton_Click(object sender, RoutedEventArgs e)
        {
            SQLiteConnection sqlite_conn;
            // Create a new database connection:
            sqlite_conn = new SQLiteConnection("Data Source=MyDatabase.db; " +
                "Version= 3; New= True; Compress= True; " +
                "FailIfMissing=True;");
            // Open the connection:
            sqlite_conn.Open();
            SQLiteCommand sqlite_cmd;
            sqlite_cmd = sqlite_conn.CreateCommand();

            if (IsResolvedCheckBox.IsChecked == true)
            {
                is_checked = "1";
            }
            else if (IsResolvedCheckBox.IsChecked == false)
            {
                is_checked = "0";
            }
            string updateTicket = "UPDATE TICKET SET ASSIGNED_TO = '" + AssignedToStr + "', CONTACT_TYPE = '"
            + ContactTypeComboBox.Text + "', CATEGORY = '" + CategoryComboBox.Text + "', IS_RESOLVED = '"
            + is_checked + "', SHORT_DESC = '" + ShortDescBox.Text + "', FULL_DESC = '" + FullDescBox.Text
            + "' WHERE TICKET_NUM= " + TicketNumStr;
            MessageBox.Show(updateTicket);
            sqlite_cmd.CommandText = updateTicket;
            sqlite_cmd.ExecuteNonQuery();
            sqlite_conn.Close();
            MessageBox.Show("Ticket Updated");
            CreateOrSearch createOrSearch = new CreateOrSearch();
            this.NavigationService.Navigate(createOrSearch);
        }
        private void addItemTest(StackPanel stackPanel, TextBox textBox, UserData obj)
        {
            TextBlock block = new TextBlock();
            // Add the text
            block.Text = obj.First_Last;

            // A little style...
            block.Margin = new Thickness(2, 3, 2, 3);
            block.Cursor = Cursors.Hand;

            // Mouse events
            block.MouseLeftButtonUp += (sender, e) =>
            {
                textBox.Text = (sender as TextBlock).Text;
            };

            block.MouseEnter += (sender, e) =>
            {
                TextBlock b = sender as TextBlock;
                b.Background = Brushes.PeachPuff;
            };

            block.MouseLeave += (sender, e) =>
            {
                TextBlock b = sender as TextBlock;
                b.Background = Brushes.Transparent;
            };

            // Add to the panel
            stackPanel.Children.Add(block);
        }
        private void AssignedToBox_KeyUp(object sender, KeyEventArgs e)
        {
            bool found = false;
            var border = (AssignedToStackPanel.Parent as ScrollViewer).Parent as Border;
            string query = (sender as TextBox).Text;
            var data = TableData.GetEmployees(query);

            if (query.Length == 0)
            {
                // Clear
                AssignedToStackPanel.Children.Clear();
                border.Visibility = System.Windows.Visibility.Collapsed;
            }
            else
            {
                border.Visibility = System.Windows.Visibility.Visible;
            }

            // Clear the list
            AssignedToStackPanel.Children.Clear();

            // Add the result
            foreach (UserData obj in data)
            {
                if (obj.First_Last.ToLower().StartsWith(query.ToLower()))
                {
                    // The word starts with this... Autocomplete must work
                    addItemTest(AssignedToStackPanel, AssignedToTextBox, obj);
                    found = true;
                }
            }

            if (!found)
            {
                AssignedToStackPanel.Children.Add(new TextBlock() { Text = "No results found." });
            }
        }
        private void AssignedToLostKeyboardFocus(object sender, KeyboardFocusChangedEventArgs e)
        {
            if (isAssignedToSet == false && AssignedToTextBox.Text != "") //If we have not yet set AssignedToStr but the AssignedToTextbox has something in it
            {
                isAssignedToSet = true; //set to true as the caret is no longer inside the AssignedToTextBox (user clicked out of it) and user is not entering values
                SQLiteConnection sqlite_conn;
                // Create a new database connection:
                sqlite_conn = new SQLiteConnection("Data Source=MyDatabase.db; " +
                    "Version= 3; New= True; Compress= True; Read Only= True;" +
                    "FailIfMissing=True;");
                sqlite_conn.Open(); // Open the connection
                SQLiteDataReader sqlite_datareader;
                SQLiteCommand sqlite_cmd;
                sqlite_cmd = sqlite_conn.CreateCommand();
                sqlite_cmd.CommandText =
                "SELECT U_ID as userid, U_FNAME||' '||U_LNAME AS firstlast " +
                "FROM USER WHERE firstlast LIKE '" + AssignedToTextBox.Text.ToString() + "%'"; //query using what was in the textbox
                sqlite_datareader = sqlite_cmd.ExecuteReader(); //We will get only the first row as it should be the closest to the content inside the textbox
                sqlite_datareader.Read(); //Gets only the first row, which contains the primary suggestion for autocompletion
                AssignedToStr = Convert.ToString(sqlite_datareader.GetValue(0)); //get column 1 value
                AssignedToTextBox.Text = Convert.ToString(sqlite_datareader.GetValue(1)); // get column 2 value
                sqlite_conn.Close(); //close the connection
                MessageBox.Show("Success!");
            }
        }
        private void AssignedToGotKeyboardFocus(object sender, KeyboardFocusChangedEventArgs e) //When user clicks inside the AssignedToTextBox
        {
            isAssignedToSet = false; //Set to false as carat is now visible in AssignedToTextBox and user is entering values
        }
    }
}
