﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Data.SQLite;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ProjectRebuild
{
    /// <summary>
    /// Interaction logic for CustomerTicketDisplay.xaml
    /// </summary>
    public partial class CustomerTicketDisplay : Page
    {
        public void getTicket(string ticket_str)
        {
            SQLiteConnection sqlite_conn;
            // Create a new database connection:
            sqlite_conn = new SQLiteConnection("Data Source= MyDatabase.db; " +
                "Version= 3; New= True; Compress= True; Read Only= True;" +
                "FailIfMissing=True;");
            // Open the connection:
            sqlite_conn.Open();
            SQLiteDataReader sqlite_datareader;
            SQLiteCommand sqlite_cmd;
            sqlite_cmd = sqlite_conn.CreateCommand();
            sqlite_cmd.CommandText = "SELECT * FROM TICKET WHERE TICKET_NUM = " + ticket_str;

            sqlite_datareader = sqlite_cmd.ExecuteReader();
            if (sqlite_datareader.Read())
            {
                TicketNumBlock.Text = Convert.ToString(sqlite_datareader.GetValue(0));
                CreatedForBlock.Text = Convert.ToString(sqlite_datareader.GetValue(1));
                CreatedByBlock.Text = Convert.ToString(sqlite_datareader.GetValue(2));
                AssignedToBlock.Text = Convert.ToString(sqlite_datareader.GetValue(3));
                ContactTypeBlock.Text = Convert.ToString(sqlite_datareader.GetValue(4));
                CategoryBlock.Text = Convert.ToString(sqlite_datareader.GetValue(5));
                IsResolvedBlock.Text = Convert.ToString(sqlite_datareader.GetValue(6));
                ShortDescBlock.Text = Convert.ToString(sqlite_datareader.GetValue(7));
                FullDescBlock.Text = Convert.ToString(sqlite_datareader.GetValue(8));
            }
            sqlite_conn.Close();
        }
        public CustomerTicketDisplay(int ticket_num, string ticket_str)
        {
            InitializeComponent();
            getTicket(ticket_str);
        }
    }
}
