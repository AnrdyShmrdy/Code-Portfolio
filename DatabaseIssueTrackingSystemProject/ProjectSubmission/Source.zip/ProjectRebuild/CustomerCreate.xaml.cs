﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Data.SQLite;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ProjectRebuild
{
    /// <summary>
    /// Interaction logic for CustomerCreate.xaml
    /// </summary>
    public partial class CustomerCreate : Page
    {
        public class Ticket
        {
            public string Contact_Type { get; set; }
            public string Category { get; set; }
            public string Short_Desc { get; set; }
            public string Full_Desc { get; set; }
        }
        public string CreatedForStr = "";
        public string CreatedByStr = "";
        public CustomerCreate(string created_by)
        {
            InitializeComponent();
            CreatedByStr = created_by; //Makes it so that we know from previous page what the user ID was
            CreatedForStr = created_by;
        }
        public string getTicketNum()
        {
            SQLiteConnection sqlite_conn;
            // Create a new database connection:
            sqlite_conn = new SQLiteConnection("Data Source=MyDatabase.db; " +
                "Version= 3; New= True; Compress= True; Read Only= True;" +
                "FailIfMissing=True;");
            // Open the connection:
            sqlite_conn.Open();
            SQLiteDataReader sqlite_datareader;
            SQLiteCommand sqlite_cmd;
            sqlite_cmd = sqlite_conn.CreateCommand();
            sqlite_cmd.CommandText = "SELECT max(TICKET_NUM) FROM TICKET";
            sqlite_datareader = sqlite_cmd.ExecuteReader();
            sqlite_datareader.Read();
            string temp = "Your Ticket Number is: " + Convert.ToString(sqlite_datareader.GetValue(0));
            sqlite_conn.Close();
            return temp;
        }
        private void CreateTicketButton_Click(object sender, RoutedEventArgs e)
        {
            SQLiteConnection sqlite_conn;
            // Create a new database connection:
            sqlite_conn = new SQLiteConnection("Data Source=MyDatabase.db; " +
                "Version= 3; New= True; Compress= True; " +
                "FailIfMissing=True;");
            // Open the connection:
            sqlite_conn.Open();
            SQLiteCommand sqlite_cmd;
            SQLiteDataReader sqlite_datareader;
            sqlite_cmd = sqlite_conn.CreateCommand();
            string insertTicket = "INSERT INTO TICKET (CREATED_FOR, CREATED_BY, ASSIGNED_TO, CONTACT_TYPE, CATEGORY, IS_RESOLVED, SHORT_DESC, FULL_DESC) " +
            "VALUES('" + CreatedForStr + "', '" + CreatedByStr + "', NULL, '" + ContactTypeComboBox.Text + "', '" +
            CategoryComboBox.Text + "', 0, '" + ShortDescBox.Text + "', '" + FullDescBox.Text + "')";
            sqlite_cmd.CommandText = insertTicket;
            sqlite_cmd.ExecuteNonQuery();
            sqlite_cmd = sqlite_conn.CreateCommand();
            sqlite_cmd.CommandText = "SELECT max(TICKET_NUM) FROM TICKET";
            sqlite_datareader = sqlite_cmd.ExecuteReader();
            sqlite_datareader.Read();
            string temp = "Your Ticket Number is: " + Convert.ToString(sqlite_datareader.GetValue(0));
            sqlite_conn.Close();
            MessageBox.Show(temp);
            CreateOrSearch createOrSearch = new CreateOrSearch();
            this.NavigationService.Navigate(createOrSearch);
        }

        private void ReturnButton_Click(object sender, RoutedEventArgs e)
        {
            CreateOrSearch createOrSearch = new CreateOrSearch();
            this.NavigationService.Navigate(createOrSearch);
        }
    }
}
